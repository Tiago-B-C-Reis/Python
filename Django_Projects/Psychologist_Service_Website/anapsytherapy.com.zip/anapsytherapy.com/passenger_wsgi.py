import os
import sys


from web_project.wsgi import application
